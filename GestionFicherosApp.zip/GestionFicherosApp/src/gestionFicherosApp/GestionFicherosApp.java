package gestionFicherosApp;

import gestionficheros.MainGUI;

public class GestionFicherosApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GestionFicherosImp1 getFicherosImp1 = new GestionFicherosImp1();
		new MainGUI(getFicherosImp1).setVisible (true);
		
		
		
		
		
	}
}
