package gestionFicherosApp;

import java.io.File;

import gestionficheros.FormatoVistas;
import gestionficheros.GestionFicheros;
import gestionficheros.GestionFicherosException;
import gestionficheros.TipoOrden;

public class GestionFicherosImp1 implements GestionFicheros {
	
	private File carpetaDeTrabajo = null;
	private Object [][] contenido;
	private int filas = 0;
	private int columnas = 3;
	private FormatoVistas formatoVistas = FormatoVistas.NOMBRES;
	private TipoOrden ordenado = TipoOrden.DESORDENADO;
	
	public GestionFicherosImp1() {
		carpetaDeTrabajo = File.listRoots()[0];
		actualiza();
	}

	private void actualiza() {
		// TODO Auto-generated method stub�
		
		String [] ficheros = carpetaDeTrabajo.list(); //obtener los nombres
		filas = ficheros.length / columnas; // calcular el n�mero de filas necesario
		if (filas * columnas < ficheros.length) {
			filas++; // si hay resto necesitamos una linea m�s.
		}
		// dimensionar la matriz contenido seg�n los resultados

				contenido = new String[filas][columnas];
				// Rellenar contenido con los nombres obtenidos
				for (int i = 0; i < columnas; i++) {
					for (int j = 0; j < filas; j++) {
						int ind = j * columnas + i;
						if (ind < ficheros.length) {
							contenido[j][i] = ficheros[ind];
						} else {
							contenido[j][i] = "";
						}
			}
	}
}

	@Override
	public void arriba() {
		// TODO Auto-generated method stub
		//volem actualitzar la carpeta de treball sobre la que estem treballant
		if (carpetaDeTrabajo.getParentFile()!=null) {
			carpetaDeTrabajo = carpetaDeTrabajo.getParentFile();
			
			actualiza();
			
		}	
	}

	@Override
	public void creaCarpeta(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
		File d = new File(carpetaDeTrabajo, arg0);
		//Excepciones
		if (!carpetaDeTrabajo.canWrite()) {
			throw new GestionFicherosException("No se ha podido crear la carpeta: no tienes permisos");
		}else if(!carpetaDeTrabajo.exists()) {
			throw new GestionFicherosException("No se ha podido crear la carpeta: no existe la carpeta padre");
		//Accion
		}else {
			d.mkdir();
			actualiza();
	}
	}

	@Override
	public void creaFichero(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void elimina(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void entraA(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
		File f = new File(carpetaDeTrabajo,arg0);
		if (!f.exists()) {
			throw /*LANZA UN ERROR*/ new GestionFicherosException ("ERROR. La ruta "
		+ f.getAbsolutePath()+"no existe");
		}
		
		
		if (!f.isDirectory()) {
			throw /*LANZA UN ERROR*/ new GestionFicherosException ("ERROR. Se esperaba un directorio, pero "
		+ f.getAbsolutePath()+"no lo es");
		}
		
		if (! f.canRead()) {
			throw new GestionFicherosException ("ERROR no se puede leer");
		}
		
		carpetaDeTrabajo = f;
		actualiza();
	}
			

	@Override
	public int getColumnas() {
		// TODO Auto-generated method stub
		return columnas;
	}

	@Override
	public Object[][] getContenido() {
		// TODO Auto-generated method stub
		return contenido;
	}

	@Override
	public String getDireccionCarpeta() {
		// TODO Auto-generated method stub
		return carpetaDeTrabajo.getAbsolutePath();
	}

	@Override
	public String getEspacioDisponibleCarpetaTrabajo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getEspacioTotalCarpetaTrabajo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getFilas() {
		// TODO Auto-generated method stub
		return filas;
	}

	public void setFilas(int filas) {
		this.filas = filas;
	}

	@Override
	public FormatoVistas getFormatoContenido() {
		// TODO Auto-generated method stub
		return formatoVistas;
	}

	@Override
	public String getInformacion(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		File f = new File(carpetaDeTrabajo,arg0);
		String cadena;
		StringBuilder sb = new StringBuilder();
		
		
		cadena = "**********INFO DEL FICHERO**********";
		cadena = cadena +"\n \n"+ "HOLAAAAAAAAAAAAAAAAA";
		
		return cadena;
				
		
		
		
	
	}

	@Override
	public boolean getMostrarOcultos() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getNombreCarpeta() {
		// TODO Auto-generated method stub
		return carpetaDeTrabajo.getName();
	}

	@Override
	public TipoOrden getOrdenado() {
		// TODO Auto-generated method stub
		return ordenado;
	}

	@Override
	public String[] getTituloColumnas() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getUltimaModificacion(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String nomRaiz(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int numRaices() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void renombra(String arg0, String arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
		File d = new File(carpetaDeTrabajo, arg0);
		//Excepciones
		if (!carpetaDeTrabajo.canWrite()) {
			throw new GestionFicherosException("No se ha podido cambiar el nombre del Archivo: no tienes permisos");
		}else if(!carpetaDeTrabajo.exists()) {
			throw new GestionFicherosException("No se ha podido cambiar el nombre del Archivo: no existe la carpeta padre");
		//Accion
		}else {
			File f = new File(carpetaDeTrabajo, arg1);
			d.renameTo(f);
			actualiza();	
		}
	}

	@Override
	public boolean sePuedeEjecutar(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean sePuedeEscribir(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean sePuedeLeer(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setColumnas(int arg0) {
		columnas = arg0;
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDirCarpeta(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		File f = new File(arg0);
		if (!f.exists()) {
			throw /*LANZA UN ERROR*/ new GestionFicherosException ("ERROR. La ruta "
		+ f.getAbsolutePath()+"no existe");
		}
		
		
		if (!f.isDirectory()) {
			throw /*LANZA UN ERROR*/ new GestionFicherosException ("ERROR. Se esperaba un directorio, pero "
		+ f.getAbsolutePath()+"no lo es");
		}
		
		if (! f.canRead()) {
			throw new GestionFicherosException ("ERROR no se puede leer");
		}
		
		carpetaDeTrabajo = f;
		actualiza();
	}

	@Override
	public void setFormatoContenido(FormatoVistas arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMostrarOcultos(boolean arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setOrdenado(TipoOrden arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setSePuedeEjecutar(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setSePuedeEscribir(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setSePuedeLeer(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setUltimaModificacion(String arg0, long arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
	}
}
